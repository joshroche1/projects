from typing import Union

from fastapi import FastAPI, Form, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel


class Person(BaseModel):
  name: Union[str, None] = None
  email: Union[str, None] = None
  role: str
  username: str
  password: str

app = FastAPI()

app.mount("/views", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

user1 = Person(name="Administrator",email="admin@admin.adm",role="Administrator",username="admin",password="adminADMIN12#$")
user2 = Person(name="User",email="user@user.usr",role="User",username="user",password="userUSER12#$")
user3 = Person(name="Guest",email="guest@guest.gst",role="Guest",username="guest",password="guestGUEST12#$")
userlist = []
userlist.append(user1)
userlist.append(user2)
userlist.append(user3)

#@app.get("/")
#async def index():
#  return RedirectResponse("/views/index.html")

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
  return templates.TemplateResponse("index.html", {"request": request, "users": userlist})

@app.post("/users/create")
async def user_create(person: Person):
  userlist.append(person)
  return person

@app.get("/users")
async def user_list():
  return userlist

@app.get("/users/{user_name}")
async def user_detail(user_name: str):
  for usr in userlist:
    if usr.username.find(user_name) > -1:
      result = usr
    else:
      result = {"message":"User not found"}
  return result

@app.post("/users/delete/{user_name}")
async def user_delete(user_name: str):
  for usr in userlist:
    if usr.username.find(user_name) > -1:
      userlist.remove(usr)
      result = {"message":"User deleted"}
    else:
      result = {"message":"User not found"}
  return result

@app.post("/users/formcreate")
async def user_form_create(name: str = Form(), email: str = Form(), role: str = Form(), username: str = Form(), password: str = Form(), passwordcheck: str = Form()):
  if password.find(passwordcheck) < 0:
    result = {"message":"Passwords must match"}
  else:
    result = Person(name=name,email=email,role=role,username=username,password=password)
    userlist.append(result)
  return result
