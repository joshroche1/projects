from typing import Union

from fastapi import Depends, FastAPI, HTTPException, Form, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from pydantic import BaseModel
from sqlalchemy.orm import Session

from .database import SessionLocal, engine
from . import models, schema
from .auth import authenticate_user, create_user, get_current_user, oauth2_scheme, get_users
from .ansible_runner import get_client_details, get_client_sessions, ban_client


### Initialization

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

messages = []
infoboxes = []
g = {}

def get_db():
  db = SessionLocal()
  try:
    yield db
  finally:
    db.close()

def message(message: str = ""):
  messages.clear()
  messages.append(message)

def infobox(infobox: str = ""):
  infoboxes.clear()
  infoboxes.append(infobox)

### Routing


@app.get("/token")
async def token_auth(token: str = Depends(oauth2_scheme)):
  return {"token": token}

@app.get("/user")
async def read_users_me(current_user: schema.User = Depends(get_current_user)):
  return current_user
#

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
  message()
  return templates.TemplateResponse("index.html", {"request": request, "messages": messages, "infoboxes": infoboxes, "g": g})

@app.get("/test", response_class=HTMLResponse)
async def test(request: Request, db: Session = Depends(get_db)):
  message()
  userlist = get_users(db)
  return templates.TemplateResponse("test.html", {"request": request, "messages": messages, "infoboxes": infoboxes, "g": g, "userlist": userlist})

@app.get("/login", response_class=HTMLResponse)
async def loginpage(request: Request):
  message()
  return templates.TemplateResponse("login.html", {"request": request, "messages": messages, "g": g})

@app.post("/login")
async def loginform(request: Request, username: str = Form(), password: str = Form(), db: Session = Depends(get_db)):
  message()
  db_user = authenticate_user(db, username, password)
  if db_user is None:
    messages.append("User not found")
    return templates.TemplateResponse("login.html", {"request": request, "messages": messages, "g": g})
  g["user"] = db_user
  return templates.TemplateResponse("index.html", {"request": request, "messages": messages, "g": g})

@app.get("/logout", response_class=HTMLResponse)
async def logout(request: Request):
  message()
  g.clear()
  return templates.TemplateResponse("index.html", {"request": request, "messages": messages, "g": g})

#

@app.get("/clear_infobox", response_class=HTMLResponse)
async def clear_infobox(request: Request):
  infobox()
  return templates.TemplateResponse("index.html", {"request": request, "messages": messages, "infoboxes": infoboxes, "g": g})

@app.post("/get_cid_details", response_class=HTMLResponse)
async def cid_details(request: Request, get_cid_details: str = Form()):
  results = get_client_details(get_cid_details)
  infobox(results)
  return templates.TemplateResponse("index.html", {"request": request, "messages": messages, "infoboxes": infoboxes, "g": g})

@app.post("/get_cid_sessions", response_class=HTMLResponse)
async def cid_sessions(request: Request, cid_sessions_count: int = Form(), cid_sessions: str = Form()):
  results = get_client_sessions(cid_sessions, cid_sessions_count)
  infobox(results)
  return templates.TemplateResponse("index.html", {"request": request, "messages": messages, "infoboxes": infoboxes, "g": g})

###