import ansible_runner



ansible_runner_private_data_dir = '/home/jroche/projects/anydesk/scamtool/ansible/'
ansible_playbook_directory = ansible_runner_private_data_dir + 'playbooks/'
ansible_hosts_file = ansible_runner_private_data_dir + 'hosts'


def parse_results(output):
  msg = ""
  result = ""
#  for x in output.stdout:
#    msg = msg + str(x)
#  tmplist = msg.split(hostname)
#  for tmp in tmplist:
#    tmp1 = tmp.split("TASK")
#    for tmp2 in tmp1:
#      if tmp2.find("WARNING") <= 0:
#        result = result + tmp2
  for x in output.stdout:
    msg = msg + str(x) + ""
  tmp1 = msg.split("PLAY RECAP")
  tmp2 = tmp1[0].split("=> {")
  tmp3 = tmp2[1]
  tmp4 = tmp3.replace("\"","").split("\\n")
  for y in tmp4:
    result = result + y + "\n"
  return result

def run_playbook(playbookfile,hostname,extravarsdict):
  def status_handler(data, runner_config):
    print(data)
  playbookfilename = ansible_playbook_directory + playbookfile
  output = ansible_runner.run(private_data_dir=ansible_runner_private_data_dir,
                         inventory=ansible_hosts_file,
                         limit=hostname,
                         playbook=playbookfilename,
                         extravars=extravarsdict,
                         status_handler=status_handler)
  result = parse_results(output)
  return result


def get_client_details(cid):
  extravarsdict = {}
  extravarsdict["cid"] = cid
  result = run_playbook("ad_cid_details.yml", "control", extravarsdict)
  return result

def get_client_sessions(cid, count):
  extravarsdict = {}
  extravarsdict["cid"] = cid
  extravarsdict["session_count"] = count
  result = run_playbook("ad_cid_sessions.yml", "control", extravarsdict)
  return result

def ban_client(cid, comments):
  return 0