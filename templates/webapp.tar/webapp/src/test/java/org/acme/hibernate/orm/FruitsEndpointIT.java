package org.acme.hibernate.orm;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class FruitsEndpointIT extends FruitsEndpointTest {

    // Runs the same tests as the parent class

}
