INSERT INTO userentity(id, username, password, role) VALUES (nextval('hibernate_sequence'), 'admin', '$2a$10$bzT1n32kCsNlIGpJtDMgIO.C23cATmOHmjCA.III3ALGOjmEpU0yq', 'admin');
